// Version information for the "BasicUsageEnvironment" library
// Copyright (c) 1996-2015 Live Networks, Inc.  All rights reserved.

#ifndef _BASICUSAGEENVIRONMENT_VERSION_HH
#define _BASICUSAGEENVIRONMENT_VERSION_HH

#define BASICUSAGEENVIRONMENT_LIBRARY_VERSION_STRING	"2015.04.22"
#define BASICUSAGEENVIRONMENT_LIBRARY_VERSION_INT		1429660800

#endif
