// Version information for the "groupsock" library
// Copyright (c) 1996-2019 Live Networks, Inc.  All rights reserved.

#ifndef _GROUPSOCK_VERSION_HH
#define _GROUPSOCK_VERSION_HH

#define GROUPSOCK_LIBRARY_VERSION_STRING	"2019.11.05"
#define GROUPSOCK_LIBRARY_VERSION_INT		1572912000

#endif
