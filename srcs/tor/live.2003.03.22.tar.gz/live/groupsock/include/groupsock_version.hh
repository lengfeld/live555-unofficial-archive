// Version information for the "groupsock" library
// Copyright (c) 1996-2003 Live Networks, Inc.  All rights reserved.

#ifndef _GROUPSOCK_VERSION_HH
#define _GROUPSOCK_VERSION_HH

#define GROUPSOCK_LIBRARY_VERSION_STRING	"2003.03.21"
#define GROUPSOCK_LIBRARY_VERSION_INT		1048204800

#endif
