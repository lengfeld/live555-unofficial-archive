// Version information for the "UsageEnvironment" library
// Copyright (c) 1996-2010 Live Networks, Inc.  All rights reserved.

#ifndef _USAGEENVIRONMENT_VERSION_HH
#define _USAGEENVIRONMENT_VERSION_HH

#define USAGEENVIRONMENT_LIBRARY_VERSION_STRING	"2010.10.28"
#define USAGEENVIRONMENT_LIBRARY_VERSION_INT		1288224000

#endif
