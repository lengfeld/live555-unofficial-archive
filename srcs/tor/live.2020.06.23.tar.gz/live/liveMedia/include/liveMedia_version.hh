// Version information for the "liveMedia" library
// Copyright (c) 1996-2020 Live Networks, Inc.  All rights reserved.

#ifndef _LIVEMEDIA_VERSION_HH
#define _LIVEMEDIA_VERSION_HH

#define LIVEMEDIA_LIBRARY_VERSION_STRING	"2020.06.23"
#define LIVEMEDIA_LIBRARY_VERSION_INT		1592870400

#endif
