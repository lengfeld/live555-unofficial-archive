// Copyright (c) 1996-2011, Live Networks, Inc.  All rights reserved
// Version information for the LIVE555 Media Server application
// Header file

#ifndef _MEDIA_SERVER_VERSION_HH
#define _MEDIA_SERVER_VERSION_HH

#define MEDIA_SERVER_VERSION_STRING "0.66"

#endif
