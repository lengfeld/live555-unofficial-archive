// Version information for the "groupsock" library
// Copyright (c) 1996-2004 Live Networks, Inc.  All rights reserved.

#ifndef _GROUPSOCK_VERSION_HH
#define _GROUPSOCK_VERSION_HH

#define GROUPSOCK_LIBRARY_VERSION_STRING	"2004.05.09"
#define GROUPSOCK_LIBRARY_VERSION_INT		1084060800

#endif
