// Version information for the "groupsock" library
// Copyright (c) 1996-2005 Live Networks, Inc.  All rights reserved.

#ifndef _GROUPSOCK_VERSION_HH
#define _GROUPSOCK_VERSION_HH

#define GROUPSOCK_LIBRARY_VERSION_STRING	"2005.07.22"
#define GROUPSOCK_LIBRARY_VERSION_INT		1121990400

#endif
