// Version information for the "BasicUsageEnvironment" library
// Copyright (c) 1996-2004 Live Networks, Inc.  All rights reserved.

#ifndef _BASICUSAGEENVIRONMENT_VERSION_HH
#define _BASICUSAGEENVIRONMENT_VERSION_HH

#define BASICUSAGEENVIRONMENT_LIBRARY_VERSION_STRING	"2004.03.23"
#define BASICUSAGEENVIRONMENT_LIBRARY_VERSION_INT		1080000000

#endif
