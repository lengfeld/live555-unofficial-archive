// Version information for the "groupsock" library
// Copyright (c) 1996-2006 Live Networks, Inc.  All rights reserved.

#ifndef _GROUPSOCK_VERSION_HH
#define _GROUPSOCK_VERSION_HH

#define GROUPSOCK_LIBRARY_VERSION_STRING	"2006.06.28"
#define GROUPSOCK_LIBRARY_VERSION_INT		1151452800

#endif
