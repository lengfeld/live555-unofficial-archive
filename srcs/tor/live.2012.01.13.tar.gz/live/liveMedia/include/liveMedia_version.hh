// Version information for the "liveMedia" library
// Copyright (c) 1996-2012 Live Networks, Inc.  All rights reserved.

#ifndef _LIVEMEDIA_VERSION_HH
#define _LIVEMEDIA_VERSION_HH

#define LIVEMEDIA_LIBRARY_VERSION_STRING	"2012.01.13"
#define LIVEMEDIA_LIBRARY_VERSION_INT		1326412800

#endif
