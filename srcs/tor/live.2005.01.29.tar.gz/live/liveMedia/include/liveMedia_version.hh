// Version information for the "liveMedia" library
// Copyright (c) 1996-2005 Live Networks, Inc.  All rights reserved.

#ifndef _LIVEMEDIA_VERSION_HH
#define _LIVEMEDIA_VERSION_HH

#define LIVEMEDIA_LIBRARY_VERSION_STRING	"2005.01.29"
#define LIVEMEDIA_LIBRARY_VERSION_INT		1106956800

#endif
