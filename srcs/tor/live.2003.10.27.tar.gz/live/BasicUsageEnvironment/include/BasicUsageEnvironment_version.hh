// Version information for the "BasicUsageEnvironment" library
// Copyright (c) 1996-2003 Live Networks, Inc.  All rights reserved.

#ifndef _BASICUSAGEENVIRONMENT_VERSION_HH
#define _BASICUSAGEENVIRONMENT_VERSION_HH

#define BASICUSAGEENVIRONMENT_LIBRARY_VERSION_STRING	"2003.10.26"
#define BASICUSAGEENVIRONMENT_LIBRARY_VERSION_INT		1067126400

#endif
