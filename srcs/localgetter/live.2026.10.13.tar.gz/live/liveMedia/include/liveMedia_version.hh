/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
**********/
// Version information for the "liveMedia" library
// Copyright (c) 1996-2026 Live Networks, Inc.  All rights reserved.

#ifndef _LIVEMEDIA_VERSION_HH
#define _LIVEMEDIA_VERSION_HH

#define LIVEMEDIA_LIBRARY_VERSION_STRING	"2026.10.13"
#define LIVEMEDIA_LIBRARY_VERSION_INT		1791849600

extern char const* const liveMediaLibraryVersionStr;
extern int const liveMediaLibraryVersionInt;

#endif
